#!/bin/sh

# 安装声卡守护进程脚本
SCRIPT_PATH="$(dirname "$0")"

cat << EOF
-- 安装声卡守护进程脚本 --

此安装程序脚本演示了shell编程技术，运行开机任务等。

要完全卸载，请手动删除以下文件:
rm -rf '/Library/LaunchAgents/com.audio.reset.plist'
rm -rf '/Library/Application Support/AudioReset/AudioReset.sh'
rm -rf '/Library/Application Support/AudioReset/hda-verb'

EOF

cat << EOF
ALC233                10ec_0233 "0x19 SET_PIN_WIDGET_CONTROL 0x25"
ALC235                10ec_0235 "0x19 SET_PIN_WIDGET_CONTROL 0x25"
ALC255                10ec_0255 "0x19 SET_PIN_WIDGET_CONTROL 0x25"
ALC269                10ec_0269 "0x15 SET_UNSOLICITED_ENABLE 0x83"
ALC269VB        10ec_0269_HDA_1028_04d9 "0x21 SET_UNSOLICITED_ENABLE 0x83"
ALC269BRIX10ec_0269_HDA_1458_fa50 "0x15 SET_UNSOLICITED_ENABLE 0x83"
ALC282                10ec_0282 "0x19 SET_PIN_WIDGET_CONTROL 0x25"
ALC283                10ec_0283 "0x19 SET_PIN_WIDGET_CONTROL 0x25"
ALC292                10ec_0292 "0x15 SET_UNSOLICITED_ENABLE 0x83"
ALC668                10ec_0668 "0x15 SET_UNSOLICITED_ENABLE 0x83"
ALC1150                10ec_0900 "0x20 SET_COEF_INDEX 0x07"
EOF
while true; do
                echo "请输入你的声卡代码(如为ALC269VB，只需输入269VB)"
                echo "如不在列表，或要自定义参数，请输入N"
                read -p "请输入代码:" arg0
                case "$arg0" in
                                "233" ) arg1="0x19 SET_PIN_WIDGET_CONTROL 0x25" break;;
                                "235" ) arg1="0x19 SET_PIN_WIDGET_CONTROL 0x25" break;;
                                "255" ) arg1="0x19 SET_PIN_WIDGET_CONTROL 0x25" break;;
                                "269" ) arg1="0x15 SET_UNSOLICITED_ENABLE 0x83" break;;
                                "269VB" ) arg1="0x21 SET_UNSOLICITED_ENABLE 0x83" break;;
                                "269BRIX" ) arg1="0x15 SET_UNSOLICITED_ENABLE 0x83" break;;
                                "282" ) arg1="0x19 SET_PIN_WIDGET_CONTROL 0x25" break;;
                                "283" ) arg1="0x19 SET_PIN_WIDGET_CONTROL 0x25" break;;
                                "292" ) arg1="0x15 SET_UNSOLICITED_ENABLE 0x83" break;;
                                "668" ) arg1="0x15 SET_UNSOLICITED_ENABLE 0x83" break;;
                                "1150" ) arg1="0x20 SET_COEF_INDEX 0x07" break;;
                                [Nn] ) echo "请自定义参数(不含引号)"
                                break;;
    esac
done                
if [ "$arg1" == "" ]
then 
                echo "如:0x19 SET_PIN_WIDGET_CONTROL 0x25"
                read -p "自定义参数为:" arg1
fi        
while true; do
                echo "每次开机将会执行如下命令:"
                echo "hda-verb" $arg1
    read -p "确认无误继续吗? [y/n]" yn
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) exit;;
        * ) echo "请回答Y或N.";;
    esac
done

# 建立临时文件夹并复制hda-verb
mkdir /tmp/audio_reset_$
sudo -p "请输入您的管理员密码:" mkdir -pv '/Library/Application Support/AudioReset'
cd "$SCRIPT_PATH"
# 检查hda-verb是否存在
if [ ! -f 'hda-verb' ]
    then
        echo "错误: 找不到 hda-verb 文件." 1>&2
        exit 1
fi
cp -rf hda-verb /tmp/audio_reset_$
cd /tmp/audio_reset_$


# 创建shell脚本
cat << EOF > audioreset.sh
#!/bin/sh
# 要完全卸载，请手动删除以下文件:
# rm -rf '/Library/LaunchAgents/com.audio.reset.plist'
# rm -rf '/Library/Application Support/AudioReset/AudioReset.sh'
# rm -rf '/Library/Application Support/AudioReset/hda-verb'

'/Library/Application Support/AudioReset/hda-verb' $arg1
exit 0
EOF
chmod -f 755 AudioReset.sh

# 创建 launchd plist 以每次开机运行一次脚本
cat << EOF > com.audio.reset.plist
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.audio.reset</string>
    <key>ProgramArguments</key>
    <array>
        <string>/Library/Application Support/AudioReset/AudioReset.sh</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
</dict>
</plist>
EOF


# 移动文件，并检查错误

if ! sudo -p "请输入您的管理员密码:" chown root com.audio.reset.plist
then
    echo "错误: 无法设置 plist 文件的所有权,脚本未安装." 1>&2
    rm -rf /tmp/audio_reset_$
    exit 1
fi


if ! sudo mv -f com.audio.reset.plist /Library/LaunchAgents/
then
    echo "错误: 无法安装 plist 文件,脚本未安装." 1>&2
    rm -rf /tmp/audio_reset_$
    exit 1
fi

if ! sudo mv -f hda-verb '/Library/Application Support/AudioReset/'
then
    echo "错误: 无法安装 hda-verb 文件,脚本未安装." 1>&2
    sudo rm -rf /tmp/audio_reset_$
    sudo rm -rf /Library/LaunchAgents/com.audio.reset.plist
    exit 1
fi

if ! sudo mv -f AudioReset.sh '/Library/Application Support/AudioReset/'
then
    echo "错误: 无法安装 shell 脚本文件,脚本未安装." 1>&2
    rm -rf /tmp/audio_reset_$
    sudo rm -rf /Library/LaunchAgents/com.audio.reset.plist
    sudo rm -rf '/Library/Application Support/AudioReset/hda-verb'
    exit 1
fi

# 安装成功，删除临时文件夹
rm -rf /tmp/audio_reset_$

echo "成功安装了脚本,请重新启动计算机."
echo "玩的开心!"

exit 0